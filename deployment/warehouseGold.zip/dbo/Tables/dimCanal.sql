CREATE TABLE [dbo].[dimCanal] (

	[Canal] varchar(8000) NULL, 
	[Descripcion] varchar(8000) NULL, 
	[skCanal] bigint NULL
);


GO
ALTER TABLE [dbo].[dimCanal] ADD CONSTRAINT FK_397dcd41_d2d8_4c21_a445_4a12dd6e5b69 FOREIGN KEY ([skCanal]) REFERENCES [dbo].[dimClientes]([skCanal]);