CREATE TABLE [dbo].[prueba_log] (

	[id] int NULL
);