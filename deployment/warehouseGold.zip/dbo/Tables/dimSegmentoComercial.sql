CREATE TABLE [dbo].[dimSegmentoComercial] (

	[Segmento] varchar(8000) NULL, 
	[DescripciónBreve] varchar(8000) NULL, 
	[skSegmentoComercial] bigint NULL
);


GO
ALTER TABLE [dbo].[dimSegmentoComercial] ADD CONSTRAINT UQ_541787f1_0da2_40ba_ae7c_102be8bca9a7 unique NONCLUSTERED ([skSegmentoComercial]);