CREATE TABLE [dbo].[dimGrupo] (

	[skGrupo] bigint NULL, 
	[Descripcion] varchar(8000) NULL
);