CREATE TABLE [dbo].[dimIndustria] (

	[Sector] varchar(8000) NULL, 
	[Descripcion] varchar(8000) NULL, 
	[skIndustria] bigint NULL
);


GO
ALTER TABLE [dbo].[dimIndustria] ADD CONSTRAINT UQ_02f2b669_c878_4460_a9c8_9728df95e021 unique NONCLUSTERED ([skIndustria]);