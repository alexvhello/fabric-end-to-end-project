CREATE TABLE [dbo].[dimEjecutivo] (

	[skEjecutivo] bigint NULL, 
	[Descripcion] varchar(8000) NULL
);