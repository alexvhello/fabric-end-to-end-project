CREATE TABLE [dbo].[prediccionesChurn] (

	[numContrato] int NULL, 
	[idCliente] int NULL, 
	[prediccion] float NULL, 
	[probabilidadChurn] float NULL
);