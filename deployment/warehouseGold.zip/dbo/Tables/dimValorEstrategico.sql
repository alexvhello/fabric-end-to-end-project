CREATE TABLE [dbo].[dimValorEstrategico] (

	[valorCliente] varchar(8000) NULL, 
	[Descripción] varchar(8000) NULL, 
	[skValorEstrategico] bigint NULL
);


GO
ALTER TABLE [dbo].[dimValorEstrategico] ADD CONSTRAINT UQ_866c202b_ca74_4e73_ab1e_db40c2b31a01 unique NONCLUSTERED ([skValorEstrategico]);