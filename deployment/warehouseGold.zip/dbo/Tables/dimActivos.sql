CREATE TABLE [dbo].[dimActivos] (

	[descripcionActivo] varchar(8000) NULL, 
	[skActivo] int NULL, 
	[skCategoriaActivo] bigint NULL
);


GO
ALTER TABLE [dbo].[dimActivos] ADD CONSTRAINT UQ_0cd6f6e0_621d_4fc8_ac31_581fcf25cb48 unique NONCLUSTERED ([skActivo]);
GO
ALTER TABLE [dbo].[dimActivos] ADD CONSTRAINT UQ_cb11c6c9_623c_43b2_959e_982eaf8055dd unique NONCLUSTERED ([skCategoriaActivo]);