CREATE TABLE [dbo].[factContratos] (

	[numContrato] varchar(8000) NULL, 
	[skCliente] int NULL, 
	[skActivo] int NULL, 
	[fechaInicio] date NULL, 
	[montoActivos] float NULL, 
	[montoSaldoAnterior] float NULL, 
	[montoNuevaCompra] float NULL, 
	[montoAbono] float NULL, 
	[moneda] varchar(8000) NULL, 
	[montoLeasing] float NULL, 
	[plazoOriginal] int NULL, 
	[plazo] int NULL, 
	[tasa] float NULL, 
	[montoDeposito] float NULL, 
	[montoDepositoAbonado] float NULL, 
	[montoSinSeguro] float NULL, 
	[montoSeguroContrato] float NULL, 
	[montoMantenimiento] float NULL, 
	[montoSeguroMantenimiento] float NULL, 
	[montoReserva] float NULL, 
	[montoCompraFinal] float NULL, 
	[montoProveedor] float NULL, 
	[diaPago] int NULL, 
	[fechaPrimerPago] date NULL, 
	[fechaUltimoPago] date NULL, 
	[fechaCancelacion] date NULL, 
	[fechaAprobacion] date NULL, 
	[fechaContraActual] date NULL, 
	[montoValorFiscal] float NULL, 
	[estado] varchar(8000) NULL, 
	[diasGraciaPrimerPago] int NULL, 
	[montoiva] float NULL, 
	[mesesGracia] int NULL, 
	[anioCancelacion] bigint NULL, 
	[cancelacion] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[factContratos] ADD CONSTRAINT FK_031b1735_d2f0_4aaa_82ad_484ca1e477a2 FOREIGN KEY ([skActivo]) REFERENCES [dbo].[dimActivos]([skActivo]);
GO
ALTER TABLE [dbo].[factContratos] ADD CONSTRAINT FK_31bf83b3_fa98_4c3b_8f22_26f1f00b3552 FOREIGN KEY ([skCliente]) REFERENCES [dbo].[dimClientes]([skCliente]);