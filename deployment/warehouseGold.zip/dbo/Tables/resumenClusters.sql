CREATE TABLE [dbo].[resumenClusters] (

	[grupo] int NULL, 
	[avg_montoSaldoAnterior] float NULL, 
	[avg_montoArrendamiento] float NULL, 
	[avg_plazoOriginal] float NULL, 
	[avg_plazo] float NULL, 
	[avg_tasa] float NULL, 
	[avg_montoDeposito] float NULL, 
	[avg_montoDepositoAbonado] float NULL, 
	[avg_montoSinSeguro] float NULL, 
	[avg_montoSeguroContrato] float NULL, 
	[avg_montoMantenimiento] float NULL, 
	[avg_montoSeguroMantenimiento] float NULL, 
	[avg_montoCompraFinal] float NULL, 
	[avg_montoProveedor] float NULL, 
	[avg_montoValorFiscal] float NULL, 
	[avg_diasGraciaPrimerPago] float NULL, 
	[avg_montoiva] float NULL
);