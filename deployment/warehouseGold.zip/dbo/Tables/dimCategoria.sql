CREATE TABLE [dbo].[dimCategoria] (

	[skCategoria] bigint NULL, 
	[nomcategoria] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[dimCategoria] ADD CONSTRAINT FK_571e298c_8081_46e5_98c7_e673b9176fc3 FOREIGN KEY ([skCategoria]) REFERENCES [dbo].[dimActivos]([skCategoriaActivo]);