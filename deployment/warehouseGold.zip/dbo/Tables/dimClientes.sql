CREATE TABLE [dbo].[dimClientes] (

	[skCliente] int NULL, 
	[nombreCliente] varchar(8000) NULL, 
	[fechaIngreso] date NULL, 
	[skSegmentoComercial] bigint NULL, 
	[skIndustria] bigint NULL, 
	[skValorEstrategico] bigint NULL, 
	[skCanal] bigint NULL
);


GO
ALTER TABLE [dbo].[dimClientes] ADD CONSTRAINT UQ_6e75fd51_b351_437b_b7d3_78e16b05d959 unique NONCLUSTERED ([skCanal]);
GO
ALTER TABLE [dbo].[dimClientes] ADD CONSTRAINT UQ_ceead4dc_f5af_4c1d_adf8_7219923963fc unique NONCLUSTERED ([skCliente]);
GO
ALTER TABLE [dbo].[dimClientes] ADD CONSTRAINT FK_63f08246_959b_4321_874f_3623f2d88c2d FOREIGN KEY ([skIndustria]) REFERENCES [dbo].[dimIndustria]([skIndustria]);
GO
ALTER TABLE [dbo].[dimClientes] ADD CONSTRAINT FK_9348ad8f_544b_4b97_b414_c72840fdf294 FOREIGN KEY ([skSegmentoComercial]) REFERENCES [dbo].[dimSegmentoComercial]([skSegmentoComercial]);
GO
ALTER TABLE [dbo].[dimClientes] ADD CONSTRAINT FK_990a0303_ec1e_4a60_9220_795454770326 FOREIGN KEY ([skValorEstrategico]) REFERENCES [dbo].[dimValorEstrategico]([skValorEstrategico]);