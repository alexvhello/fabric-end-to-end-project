CREATE TABLE [dbo].[prediccionesClusters] (

	[numContrato] int NULL, 
	[idCliente] int NULL, 
	[grupo] int NULL
);